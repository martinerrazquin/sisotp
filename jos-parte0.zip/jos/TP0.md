TP0: Introducción a JOS
=======================

backtrace_func_names
--------------------

Salida del comando `backtrace`:

```
K> backtrace
...
```
